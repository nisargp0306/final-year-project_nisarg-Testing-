# ATT_STS414
A repo to hold testing and website files for Automated Testing course of STS414

Just create "backend" database in your sql and then run the system. The system will create necessary tables automatically.

You can use the website at http://localhost:8081 You can use the admin section at http://localhost:8081/admin

You will have to create admin from phpmyadmin or by inserting sql query so that you can login as admin on admin area.
