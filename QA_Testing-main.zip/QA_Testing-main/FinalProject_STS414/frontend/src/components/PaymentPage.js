import StripeContainer from './StripeContainer';

export default function PaymentPage() {
    return(
        <StripeContainer/> 
    )
}