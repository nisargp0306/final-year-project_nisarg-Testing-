export const AUTH = 'AUTH';
export const LOGOUT = 'LOGOUT';
